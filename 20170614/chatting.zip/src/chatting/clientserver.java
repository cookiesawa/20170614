package chatting;

import javax.swing.JOptionPane;


public class clientserver {

	
	public static void main(String [] args){
		
		Object[] selectioValues = { "서버","클라이언트"};
		String initialSection = "서버";
		
		Object selection = JOptionPane.showInputDialog(null, "로그인 : ", "정경과 2학년 C반", 
				JOptionPane.QUESTION_MESSAGE, null, selectioValues, initialSection);
		if(selection.equals("서버")){
                   String[] arguments = new String[] {};
			new multithread().main(arguments);
		}else if(selection.equals("클라이언트")){
			String IPServer = JOptionPane.showInputDialog("IP 입력하세요");
                        String[] arguments = new String[] {IPServer};
			new chatclient().main(arguments);
		}
		
	}

}
