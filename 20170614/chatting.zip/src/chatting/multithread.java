package chatting;

import java.io.PrintStream;
import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;

public class multithread {
  private static ServerSocket serverSocket = null;
  private static Socket clientSocket = null;
  private static final int maxClientsCount = 10;
  private static final thread[] threads = new thread[maxClientsCount];

  public static void main(String args[]) {

    int portNumber = 2222;
    if (args.length < 1) {
      System.out.println("사용중인 포트넘버" + portNumber);
    } else {
      portNumber = Integer.valueOf(args[0]).intValue();
    }
    try {
      serverSocket = new ServerSocket(portNumber);
      System.out.println("ip : " + serverSocket.toString());
    } catch (IOException e) {
      System.out.println(e);
    }

    while (true) {
      try {
        clientSocket = serverSocket.accept();
        int i = 0;
        for (i = 0; i < maxClientsCount; i++) {
          if (threads[i] == null) {
            (threads[i] = new thread(clientSocket, threads)).start();
            break;
          }
        }
        if (i == maxClientsCount) {
          PrintStream os = new PrintStream(clientSocket.getOutputStream());
          os.println("서버 과부화.");
          os.close();
          clientSocket.close();
        }
      } catch (IOException e) {
        System.out.println(e);
      }
    }
  }  
}
