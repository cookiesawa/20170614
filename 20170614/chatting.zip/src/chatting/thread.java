package chatting;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;

public class thread extends Thread{
     private String clientName = null;
  private BufferedReader is = null;
  private PrintStream os = null;
  private Socket clientSocket = null;
  private final thread[] threads;
  private int maxClientsCount;

  public thread(Socket clientSocket, thread[] threads) {
    this.clientSocket = clientSocket;
    this.threads = threads;
    maxClientsCount = threads.length;
  }

  public void run() {
    int maxClientsCount = this.maxClientsCount;
    thread[] threads = this.threads;

    try {
		
      is = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

      os = new PrintStream(clientSocket.getOutputStream());
      String name;
      while (true) {
        os.println("닉네임을 입력하세요.");
        name = is.readLine().trim();
        if (name.indexOf('@') == -1) {
          break;
        } else {
          os.println("@는 포함될 수 없습니다.");
        }
      }

      os.println("*환영합니다. " + name
          + " 님 정경과 2학년 C반에 온걸 환영합니다.*");
      synchronized (this) {
        for (int i = 0; i < maxClientsCount; i++) {
          if (threads[i] != null && threads[i] == this) {
            clientName = "@" + name;
            break;
          }
        }
        for (int i = 0; i < maxClientsCount; i++) {
          if (threads[i] != null && threads[i] != this) {
            threads[i].os.println("** " + name
                + " 님이 입장하셨습니다.**");
          }
        }
      }
      while (true) {
        String line = is.readLine();
        
        System.out.println(line);
        if (line.startsWith("/quit")) {
          break;
        }
        if (line.startsWith("@")) {
          String[] words = line.split("\\s", 2);
          if (words.length > 1 && words[1] != null) {
            words[1] = words[1].trim();
            if (!words[1].isEmpty()) {
              synchronized (this) {
                for (int i = 0; i < maxClientsCount; i++) {
                  if (threads[i] != null && threads[i] != this
                      && threads[i].clientName != null
                      && threads[i].clientName.equals(words[0])) {
                    threads[i].os.println("<" + name + "> " + words[1]);

                    this.os.println(">" + name + "> " + words[1]);
                    break;
                  }
                }
              }
            }
          }
        } else {
          synchronized (this) {
            for (int i = 0; i < maxClientsCount; i++) {
              if (threads[i] != null && threads[i].clientName != null) {
                threads[i].os.println("<" + name + "> " + line);
              }
            }
          }
        }
      }
      synchronized (this) {
        for (int i = 0; i < maxClientsCount; i++) {
          if (threads[i] != null && threads[i] != this
              && threads[i].clientName != null) {
            threads[i].os.println("**" + name
                + " 님이 나가셨습니다.**");
          }
        }
      }
      os.println("*" + name + " 님 안녕히가세요*");

      synchronized (this) {
        for (int i = 0; i < maxClientsCount; i++) {
          if (threads[i] == this) {
            threads[i] = null;
          }
        }
      }
      is.close();
      os.close();
      clientSocket.close();
    } catch (IOException e) {
    }
  }
}
